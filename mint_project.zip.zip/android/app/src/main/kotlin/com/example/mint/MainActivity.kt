package com.example.mint

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
